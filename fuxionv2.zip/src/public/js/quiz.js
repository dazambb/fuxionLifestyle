// ===== PRODUCT QUIZ LOGIC =====

let currentQuestionNumber = 1;
const totalQuestionsCount = 6;
let quizAnswers = {};

// Product database con recomendaciones basadas en respuestas
const productDatabase = {
    energia: {
        name: "FuXion Energy Boost",
        description: "Mezcla energizante natural con guaraná, maca y vitaminas del complejo B",
        benefits: ["Aumenta energía", "Mejora concentración", "Sin cafeína artificial"],
        image: "https://images.unsplash.com/photo-1571613316887-6f8d5cbf7ef7?w=400"
    },
    peso: {
        name: "FuXion Slim Control",
        description: "Fórmula avanzada para control de peso con extractos naturales",
        benefits: ["Control de apetito", "Metabolismo activo", "100% natural"],
        image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400"
    },
    inmunidad: {
        name: "FuXion Immune Defense",
        description: "Potente complejo de vitaminas C, D, zinc y equinácea",
        benefits: ["Fortalece defensas", "Antioxidante", "Recuperación rápida"],
        image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400"
    },
    digestion: {
        name: "FuXion Digestive Pro",
        description: "Probióticos y enzimas digestivas para salud intestinal",
        benefits: ["Mejora digestión", "Flora intestinal", "Reduce inflamación"],
        image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400"
    },
    bienestar: {
        name: "FuXion Wellness Plus",
        description: "Multivitamínico completo para bienestar integral",
        benefits: ["Nutrición completa", "Vitalidad diaria", "Balance perfecto"],
        image: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=400"
    },
    deportivo: {
        name: "FuXion Performance Pro",
        description: "Suplemento para deportistas con proteínas y aminoácidos",
        benefits: ["Rendimiento deportivo", "Recuperación muscular", "Resistencia"],
        image: "https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?w=400"
    },
    detox: {
        name: "FuXion Detox Green",
        description: "Limpieza natural con superalimentos verdes y antioxidantes",
        benefits: ["Desintoxicación", "Alcaliniza el cuerpo", "Energía natural"],
        image: "https://images.unsplash.com/photo-1610970881699-44a5587cabec?w=400"
    },
    mental: {
        name: "FuXion Brain Focus",
        description: "Nootrópicos naturales para claridad mental y concentración",
        benefits: ["Claridad mental", "Memoria mejorada", "Reduce estrés"],
        image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400"
    }
};

function startQuiz() {
    document.getElementById('quizStart').style.display = 'none';
    document.getElementById('quizQuestions').style.display = 'block';
    document.getElementById('quizProgress').style.display = 'block';
    
    // Reset quiz state
    currentQuestionNumber = 1;
    quizAnswers = {};
    
    // Show first question
    showQuestion(1);
    updateProgress();
}

function showQuestion(questionNum) {
    // Hide all questions
    const allQuestions = document.querySelectorAll('.question-card');
    allQuestions.forEach(q => {
        q.style.display = 'none';
        // Reset selections
        q.querySelectorAll('.option-btn').forEach(btn => {
            btn.classList.remove('selected');
        });
    });
    
    // Show current question with animation
    const currentQuestion = document.querySelector(`[data-question="${questionNum}"]`);
    if (currentQuestion) {
        setTimeout(() => {
            currentQuestion.style.display = 'block';
            currentQuestion.classList.add('fade-in-up');
        }, 100);
    }
    
    // Update navigation buttons
    const prevBtn = document.getElementById('prevBtn');
    if (questionNum === 1) {
        prevBtn.style.display = 'none';
    } else {
        prevBtn.style.display = 'inline-block';
    }
    
    currentQuestionNumber = questionNum;
    updateProgress();
}

function selectOption(button, questionNum, value) {
    // Remove previous selection
    const questionCard = button.closest('.question-card');
    questionCard.querySelectorAll('.option-btn').forEach(btn => {
        btn.classList.remove('selected');
    });
    
    // Add selection to clicked button
    button.classList.add('selected');
    
    // Store answer
    quizAnswers[`q${questionNum}`] = value;
    
    // Move to next question after short delay
    setTimeout(() => {
        if (questionNum < totalQuestionsCount) {
            showQuestion(questionNum + 1);
        } else {
            // Quiz completed, show results
            showResults();
        }
    }, 500);
}

function previousQuestion() {
    if (currentQuestionNumber > 1) {
        showQuestion(currentQuestionNumber - 1);
    }
}

function updateProgress() {
    const percent = Math.round((currentQuestionNumber / totalQuestionsCount) * 100);
    document.getElementById('currentQuestion').textContent = currentQuestionNumber;
    document.getElementById('totalQuestions').textContent = totalQuestionsCount;
    document.getElementById('progressPercent').textContent = percent;
    document.getElementById('progressBar').style.width = percent + '%';
}

function showResults() {
    // Hide questions
    document.getElementById('quizQuestions').style.display = 'none';
    document.getElementById('quizProgress').style.display = 'none';
    
    // Show results
    document.getElementById('quizResults').style.display = 'block';
    
    // Calculate recommended products
    const recommendedProducts = getRecommendedProducts();
    displayRecommendedProducts(recommendedProducts);
    
    // Scroll to results
    document.getElementById('quizResults').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function getRecommendedProducts() {
    const products = [];
    
    // Logic to recommend products based on answers
    const objetivo = quizAnswers.q1;
    const actividad = quizAnswers.q2;
    const horario = quizAnswers.q3;
    const edad = quizAnswers.q5;
    const mejora = quizAnswers.q6;
    
    // Primary recommendation based on main goal
    if (objetivo) {
        products.push(productDatabase[objetivo]);
    }
    
    // Secondary recommendations based on activity level
    if (actividad === 'intenso' || actividad === 'moderado') {
        if (!products.find(p => p.name === productDatabase.deportivo.name)) {
            products.push(productDatabase.deportivo);
        }
    }
    
    // Recommendation based on daily improvement goal
    if (mejora === 'concentracion') {
        if (!products.find(p => p.name === productDatabase.mental.name)) {
            products.push(productDatabase.mental);
        }
    } else if (mejora === 'estres') {
        if (!products.find(p => p.name === productDatabase.bienestar.name)) {
            products.push(productDatabase.bienestar);
        }
    }
    
    // Always recommend detox as complementary
    if (products.length < 3 && !products.find(p => p.name === productDatabase.detox.name)) {
        products.push(productDatabase.detox);
    }
    
    // Limit to top 3 products
    return products.slice(0, 3);
}

function displayRecommendedProducts(products) {
    const container = document.getElementById('recommendedProducts');
    container.innerHTML = '';
    
    products.forEach((product, index) => {
        const productCard = `
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="${index * 100}">
                <div class="card h-100 border-0 shadow-sm product-recommendation">
                    <img src="${product.image}" class="card-img-top" alt="${product.name}" style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <div class="badge bg-primary mb-2">Recomendado para ti</div>
                        <h5 class="card-title">${product.name}</h5>
                        <p class="card-text text-muted">${product.description}</p>
                        <ul class="list-unstyled">
                            ${product.benefits.map(benefit => `
                                <li class="mb-1">
                                    <i class="fas fa-check text-success"></i> ${benefit}
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                    <div class="card-footer bg-transparent border-0">
                        <a href="/productos" class="btn btn-outline-primary w-100">
                            <i class="fas fa-shopping-cart"></i> Ver Producto
                        </a>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML += productCard;
    });
    
    // Re-initialize AOS for new elements
    if (typeof AOS !== 'undefined') {
        AOS.refresh();
    }
}

function restartQuiz() {
    document.getElementById('quizResults').style.display = 'none';
    document.getElementById('quizStart').style.display = 'block';
    quizAnswers = {};
    currentQuestionNumber = 1;
}

function shareResults() {
    const text = '¡Acabo de descubrir mis productos FuXion ideales! Haz el quiz tú también:';
    const url = window.location.href;
    
    // Check if Web Share API is available
    if (navigator.share) {
        navigator.share({
            title: 'Quiz de Productos FuXion',
            text: text,
            url: url
        }).catch(err => console.log('Error sharing:', err));
    } else {
        // Fallback: Copy to clipboard
        const fullText = `${text} ${url}`;
        navigator.clipboard.writeText(fullText).then(() => {
            alert('¡Link copiado al portapapeles! Compártelo con tus amigos.');
        }).catch(err => {
            console.error('Error copying to clipboard:', err);
        });
    }
}

// Email results form handler
document.addEventListener('DOMContentLoaded', function() {
    const resultsEmailForm = document.getElementById('resultsEmailForm');
    if (resultsEmailForm) {
        resultsEmailForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = document.getElementById('resultEmail').value;
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Enviando...';
            submitBtn.disabled = true;
            
            try {
                // Obtener los productos recomendados actuales
                const recommendedProducts = getRecommendedProducts();
                
                // Enviar al servidor
                const response = await fetch('/api/quiz/send-results', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        email: email,
                        name: '', // Puedes pedirlo en el formulario si quieres
                        products: recommendedProducts,
                        answers: quizAnswers
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Success
                    showNotification('✅ ¡Resultados enviados a tu email! Revisa tu bandeja de entrada.', 'success');
                    this.reset();
                } else {
                    showNotification('❌ ' + (data.error || 'Hubo un error al enviar. Por favor, intenta nuevamente.'), 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                showNotification('❌ Hubo un error al enviar. Por favor, intenta nuevamente.', 'error');
            } finally {
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
            }
        });
    }
});

// Función para mostrar notificaciones
function showNotification(message, type) {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'success' ? 'success' : 'danger'} alert-dismissible fade show`;
    notification.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 9999; min-width: 300px; box-shadow: 0 4px 12px rgba(0,0,0,0.15);';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remover después de 5 segundos
    setTimeout(() => {
        notification.remove();
    }, 5000);
}
