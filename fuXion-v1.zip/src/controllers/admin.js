const connection = require("../db/connection");
const bcrypt = require('bcryptjs');
const { generateToken } = require('../middleware/auth');

// ============ AUTENTICACIÓN ============

// Mostrar página de login
const showLogin = (req, res) => {
    res.render('admin/login', {
        title: 'Admin Login - FuXion',
        layout: 'admin/layout-auth',
        error: null
    });
};

// Procesar login
const processLogin = async (req, res) => {
    try {
        const { username, password } = req.body;
        
        const query = 'SELECT * FROM admin_users WHERE username = ? LIMIT 1';
        connection.query(query, [username], async (error, results) => {
            if (error) {
                return res.render('admin/login', {
                    title: 'Admin Login - FuXion',
                    layout: 'admin/layout-auth',
                    error: 'Error en el servidor'
                });
            }
            
            if (results.length === 0) {
                return res.render('admin/login', {
                    title: 'Admin Login - FuXion',
                    layout: 'admin/layout-auth',
                    error: 'Usuario o contraseña incorrectos'
                });
            }
            
            const user = results[0];
            
            // Verificar contraseña
            const validPassword = await bcrypt.compare(password, user.password);
            
            if (!validPassword) {
                return res.render('admin/login', {
                    title: 'Admin Login - FuXion',
                    layout: 'admin/layout-auth',
                    error: 'Usuario o contraseña incorrectos'
                });
            }
            
            // Generar token
            const token = generateToken(user);
            
            // Guardar token en cookie
            res.cookie('admin_token', token, {
                httpOnly: true,
                maxAge: 7 * 24 * 60 * 60 * 1000 // 7 días
            });
            
            res.redirect('/admin/dashboard');
        });
    } catch (error) {
        console.error(error);
        res.render('admin/login', {
            title: 'Admin Login - FuXion',
            layout: 'admin/layout-auth',
            error: 'Error en el servidor'
        });
    }
};

// Logout
const logout = (req, res) => {
    res.clearCookie('admin_token');
    res.redirect('/admin/login');
};

// ============ DASHBOARD ============

const dashboard = (req, res) => {
    // Obtener estadísticas
    const statsQuery = `
        SELECT 
            (SELECT COUNT(*) FROM products WHERE active = 1) as products_count,
            (SELECT COUNT(*) FROM blog_posts WHERE published = 1) as posts_count,
            (SELECT COUNT(*) FROM contacts WHERE read_status = 0) as unread_contacts,
            (SELECT COUNT(*) FROM distributor_requests WHERE status = 'pending') as pending_distributors,
            (SELECT COUNT(*) FROM newsletter_subscribers WHERE active = 1) as subscribers_count
    `;
    
    connection.query(statsQuery, (error, stats) => {
        if (error) {
            console.error(error);
            return res.status(500).send('Error al obtener estadísticas');
        }
        
        res.render('admin/dashboard', {
            title: 'Dashboard - Admin FuXion',
            layout: 'admin/layout',
            stats: stats[0],
            user: req.user
        });
    });
};

// ============ PRODUCTOS ============

// Listar productos
const listProducts = (req, res) => {
    const query = 'SELECT * FROM products ORDER BY display_order ASC, created_at DESC';
    
    connection.query(query, (error, products) => {
        if (error) {
            console.error(error);
            return res.status(500).send('Error al obtener productos');
        }
        
        res.render('admin/products/list', {
            title: 'Productos - Admin FuXion',
            layout: 'admin/layout',
            products: products,
            user: req.user
        });
    });
};

// Mostrar formulario de nuevo producto
const newProductForm = (req, res) => {
    res.render('admin/products/form', {
        title: 'Nuevo Producto - Admin FuXion',
        layout: 'admin/layout',
        product: null,
        user: req.user
    });
};

// Crear producto
const createProduct = (req, res) => {
    const { name, slug, category, description, benefits, ingredients, image_url, fuxion_url, featured, active, display_order } = req.body;
    
    const query = `
        INSERT INTO products (name, slug, category, description, benefits, ingredients, image_url, fuxion_url, featured, active, display_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    const values = [
        name,
        slug || name.toLowerCase().replace(/\s+/g, '-'),
        category,
        description,
        benefits,
        ingredients,
        image_url,
        fuxion_url,
        featured === 'on' ? 1 : 0,
        active === 'on' ? 1 : 0,
        display_order || 0
    ];
    
    connection.query(query, values, (error) => {
        if (error) {
            console.error(error);
            return res.status(500).send('Error al crear producto');
        }
        
        res.redirect('/admin/products?success=created');
    });
};

// Mostrar formulario de edición
const editProductForm = (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM products WHERE id = ?';
    
    connection.query(query, [id], (error, results) => {
        if (error || results.length === 0) {
            return res.status(404).send('Producto no encontrado');
        }
        
        res.render('admin/products/form', {
            title: 'Editar Producto - Admin FuXion',
            layout: 'admin/layout',
            product: results[0],
            user: req.user
        });
    });
};

// Actualizar producto
const updateProduct = (req, res) => {
    const { id } = req.params;
    const { name, slug, category, description, benefits, ingredients, image_url, fuxion_url, featured, active, display_order } = req.body;
    
    const query = `
        UPDATE products 
        SET name = ?, slug = ?, category = ?, description = ?, benefits = ?, ingredients = ?, 
            image_url = ?, fuxion_url = ?, featured = ?, active = ?, display_order = ?
        WHERE id = ?
    `;
    
    const values = [
        name,
        slug,
        category,
        description,
        benefits,
        ingredients,
        image_url,
        fuxion_url,
        featured === 'on' ? 1 : 0,
        active === 'on' ? 1 : 0,
        display_order || 0,
        id
    ];
    
    connection.query(query, values, (error) => {
        if (error) {
            console.error(error);
            return res.status(500).send('Error al actualizar producto');
        }
        
        res.redirect('/admin/products?success=updated');
    });
};

// Eliminar producto
const deleteProduct = (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM products WHERE id = ?';
    
    connection.query(query, [id], (error) => {
        if (error) {
            console.error(error);
            return res.status(500).json({ success: false });
        }
        
        res.json({ success: true });
    });
};

// ============ BLOG ============

// Listar posts
const listPosts = (req, res) => {
    const query = 'SELECT * FROM blog_posts ORDER BY created_at DESC';
    
    connection.query(query, (error, posts) => {
        if (error) {
            console.error(error);
            return res.status(500).send('Error al obtener posts');
        }
        
        res.render('admin/blog/list', {
            title: 'Blog - Admin FuXion',
            layout: 'admin/layout',
            posts: posts,
            user: req.user
        });
    });
};

// Mostrar formulario de nuevo post
const newPostForm = (req, res) => {
    res.render('admin/blog/form', {
        title: 'Nuevo Artículo - Admin FuXion',
        layout: 'admin/layout',
        post: null,
        user: req.user
    });
};

// Crear post
const createPost = (req, res) => {
    const { title, slug, excerpt, content, image_url, author, featured, published } = req.body;
    
    const query = `
        INSERT INTO blog_posts (title, slug, excerpt, content, image_url, author, featured, published, published_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    const values = [
        title,
        slug || title.toLowerCase().replace(/\s+/g, '-'),
        excerpt,
        content,
        image_url,
        author || 'FuXion Team',
        featured === 'on' ? 1 : 0,
        published === 'on' ? 1 : 0,
        published === 'on' ? new Date() : null
    ];
    
    connection.query(query, values, (error) => {
        if (error) {
            console.error(error);
            return res.status(500).send('Error al crear post');
        }
        
        res.redirect('/admin/blog?success=created');
    });
};

// Mostrar formulario de edición de post
const editPostForm = (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM blog_posts WHERE id = ?';
    
    connection.query(query, [id], (error, results) => {
        if (error || results.length === 0) {
            return res.status(404).send('Post no encontrado');
        }
        
        res.render('admin/blog/form', {
            title: 'Editar Artículo - Admin FuXion',
            layout: 'admin/layout',
            post: results[0],
            user: req.user
        });
    });
};

// Actualizar post
const updatePost = (req, res) => {
    const { id } = req.params;
    const { title, slug, excerpt, content, image_url, author, featured, published } = req.body;
    
    // Obtener estado anterior
    connection.query('SELECT published FROM blog_posts WHERE id = ?', [id], (err, results) => {
        const wasPublished = results[0].published;
        const isPublished = published === 'on' ? 1 : 0;
        
        const query = `
            UPDATE blog_posts 
            SET title = ?, slug = ?, excerpt = ?, content = ?, image_url = ?, author = ?, 
                featured = ?, published = ?, published_at = ?
            WHERE id = ?
        `;
        
        const values = [
            title,
            slug,
            excerpt,
            content,
            image_url,
            author,
            featured === 'on' ? 1 : 0,
            isPublished,
            (!wasPublished && isPublished) ? new Date() : results[0].published_at,
            id
        ];
        
        connection.query(query, values, (error) => {
            if (error) {
                console.error(error);
                return res.status(500).send('Error al actualizar post');
            }
            
            res.redirect('/admin/blog?success=updated');
        });
    });
};

// Eliminar post
const deletePost = (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM blog_posts WHERE id = ?';
    
    connection.query(query, [id], (error) => {
        if (error) {
            console.error(error);
            return res.status(500).json({ success: false });
        }
        
        res.json({ success: true });
    });
};

module.exports = {
    // Auth
    showLogin,
    processLogin,
    logout,
    // Dashboard
    dashboard,
    // Products
    listProducts,
    newProductForm,
    createProduct,
    editProductForm,
    updateProduct,
    deleteProduct,
    // Blog
    listPosts,
    newPostForm,
    createPost,
    editPostForm,
    updatePost,
    deletePost
};
