const router = require('express').Router();
const admin = require('../../controllers/admin');
const { authMiddleware } = require('../../middleware/auth');

// Auth routes (sin middleware)
router.get('/login', admin.showLogin);
router.post('/login', admin.processLogin);
router.get('/logout', admin.logout);

// Dashboard (con middleware)
router.get('/dashboard', authMiddleware, admin.dashboard);
router.get('/', authMiddleware, (req, res) => res.redirect('/admin/dashboard'));

// Products routes
router.get('/products', authMiddleware, admin.listProducts);
router.get('/products/new', authMiddleware, admin.newProductForm);
router.post('/products/new', authMiddleware, admin.createProduct);
router.get('/products/edit/:id', authMiddleware, admin.editProductForm);
router.post('/products/edit/:id', authMiddleware, admin.updateProduct);
router.delete('/products/delete/:id', authMiddleware, admin.deleteProduct);

// Blog routes
router.get('/blog', authMiddleware, admin.listPosts);
router.get('/blog/new', authMiddleware, admin.newPostForm);
router.post('/blog/new', authMiddleware, admin.createPost);
router.get('/blog/edit/:id', authMiddleware, admin.editPostForm);
router.post('/blog/edit/:id', authMiddleware, admin.updatePost);
router.delete('/blog/delete/:id', authMiddleware, admin.deletePost);

module.exports.router = router;
